files.cdir("ms0:/PSP/GAME/NINOS/SYSTEM/SYSTEM32")
require=("ASR")
timg="ACC/IMGPR/default.png" tpass="" vpass="" 
local esci=true bpass=false yimg=0 ESCI=true ok=true X=440 Y=232 off=true
x=0 y=0 
starts=image.load("ICONE/start.png")
starth=image.load("ICONE/starth.png")
vol=image.load("ICONE/volume.png")
mute=image.load("ICONE/mute.png")
chiudi=image.load("ICONE/chiudi.png")
chiudih=image.load("ICONE/chiudih.png")
riduci=image.load("ICONE/riduci.png")
riducih=image.load("ICONE/riducih.png")
freccia=image.load("ICONE/mouse.png")
b5=image.load("ICONE/batteria5.png")
b25=image.load("ICONE/batteria25.png")
b50=image.load("ICONE/batteria50.png")
b75=image.load("ICONE/batteria75.png")
b100=image.load("ICONE/batteria100.png")
spegnis=image.load("ICONE/spegni.png")
spegnih=image.load("ICONE/spegnih.png")

timg=ini.read("ACC/Account.ini","USER1","immagine","")
tpass=ini.read("ACC/Account.ini","USER1","password","")
tuser=ini.read("ACC/Account.ini","USER1","username","")
imgpr=image.load(timg)

while esci==true do
buttons.read()
screen.clear(color.new(0,0,0))
image.blit(back_bl,0,0)
if x>=210 and x<=270 and y>=195 and y<=205 and ok==false then
    draw.fillrect(208,193,64,14,color.new(0,0,0))
    if buttons.cross then
        vpass=osk.init("password","root")
        ESCI=false
    end
end
if ok==false then
    draw.fillrect(200,50,80,160,color.new(147,147,147))
    screen.print(210,140,"Username",0.5)
    screen.print(210,150,tuser,0.5)
    if tpass ~= "" then
        draw.fillrect(210,195,60,10,color.new(255,255,255))
        screen.print(210,180,"Password",0.5)
        screen.print(212,195,vpass,0.5,color.new(0,0,0))
    else
        ESCI=false
    end
end
image.blit(imgpr,215,60)
if x>=215 and x<=265 and y>=60 and y<=110 then
    if buttons.cross then
        ok=false
    end
elseif x<215 or x>265 or x>=215 and x<=265 and y<60 or y>110 then
    if buttons.cross then
        ok=true
    end
end
if vpass==tpass and ESCI==false then
    while yimg > -272 do
        screen.clear(color.new(0,0,0))
        image.blit(back_bl,0,yimg)
        screen.flip()
        yimg=yimg-3
    end
    esci=false
end
if off==false then
    image.blit(spegnih,X-40,Y)
    draw.fillrect(X-60,Y-45,60,42,color.new(210,210,210))
    if x>=X-60 and x<=X and y>=Y-18 and y<=Y-3 then
        draw.fillrect(X-60,Y-17,60,14,color.new(147,147,147))
        if buttons.cross then
            spegni()
        end
    elseif x>=X-60 and x<=X and y<=Y-17 and y>=Y-31 then
        draw.fillrect(X-60,Y-31,60,14,color.new(147,147,147))
        if buttons.cross then
            riavvia()
        end
    elseif x>=X-60 and x<=X and y<=Y-34 and y>=Y-45 then
        draw.fillrect(X-60,Y-45,60,14,color.new(147,147,147))
        if buttons.cross then
            xmb()
        end
    end
    screen.print(X-55,Y-17,"Spegni",0.5,color.new(0,0,0))
    screen.print(X-55,Y-31,"Riavvia",0.5,color.new(0,0,0))
    screen.print(X-55,Y-45,"XMB",0.5,color.new(0,0,0))
    
else
    image.blit(spegnis,X-40,Y)
end
if x>=X-40 and x<=X-20 and y>=Y and y<=Y+20 and buttons.cross then 
    if buttons.cross then
        off=false
    end
elseif x<X-40 or x>X-20 or x>=X-40 and x<=X-20 and  y<Y or y>Y+20 then
    if buttons.cross then
        off=true
    end
end
screen.print(0,220,string.sub(os.getdate(),17,-4),2,color.new(0,0,0))
screen.print(13,250,string.sub(os.getdate(),1,14),0.8,color.new(0,0,0))
batteria(x,y,X,Y,b5,b25,b50,b75,b100)
x,y=mouse(x,y,freccia)
screen.flip()
end
dofile("ms0:/PSP/GAME/NINOS/SYSTEM/SYSTEM32/desktop.lua")
