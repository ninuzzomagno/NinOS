files.cdir("ms0:/PSP/GAME/NinOS")
require=("SYSTEM.SYSTEM32.ASR")
require=("SCRIPT")

local SISTEMA_ICO=image.load("SYSTEM/SYSTEM32/ICONE/sistema.png")
local sistema1=image.load("SYSTEM/SYSTEM32/PROGRAM/Sistema1.jpg")
local sistema5=image.load("SYSTEM/SYSTEM32/PROGRAM/Sistema5.jpg")
local sistema2=image.load("SYSTEM/SYSTEM32/PROGRAM/Sistema2.jpg")
local sistema3=image.load("SYSTEM/SYSTEM32/PROGRAM/Sistema3.jpg")
local sistema4=image.load("SYSTEM/SYSTEM32/PROGRAM/Sistema4.jpg")
local ripristino=image.load("SYSTEM/SYSTEM32/ICONE/ripristino.png")
local ripristinoh=image.load("SYSTEM/SYSTEM32/ICONE/ripristinoh.png")
local ripristino2=image.load("SYSTEM/SYSTEM32/ICONE/ripristino2.png")
local ripristino2h=image.load("SYSTEM/SYSTEM32/ICONE/ripristino2h.png")
local IMG_ACC_ATT=ini.read("SYSTEM/SYSTEM32/ACC/Account.ini","USER1","immagine","")

function SISTEMA_menu()
	screen.print((148-screen.textwidth("Account",0.7))/2,35,"Account",0.7,nero)
	screen.print((148-screen.textwidth("Sistema",0.7))/2,65,"Sistema",0.7,nero)
	screen.print((148-screen.textwidth("Ripristino",0.7))/2,95,"Ripristino",0.7,nero)
	screen.print((148-screen.textwidth("Aggiorna",0.7))/2,125,"Aggiorna",0.7,nero)
	screen.print((148-screen.textwidth("Personalizza",0.7))/2,155,"Personalizza",0.7,nero)
end

function SISTEMA_ESCI()
	if x>450 and x<470 and y>2 and y<22 then
		image.blit(chiudih,450,2)
    		if buttons.cross then
			ripristino = nil
			ripristinoh = nil
			ripristino2 = nil
			ripristino2h = nil
			SISTEMA_pagina=nil
			sistema1=nil
			sistema2=nil
			sistema3=nil
			sistema4=nil
			pagina=nil
			CPU=nil
			X=nil
			Y=nil
			NICK=nil
			destroy_thread(4,getproc_thread())
        		dofile("SYSTEM/SYSTEM32/desktop.lua")
    		end
	else image.blit(chiudi,450,2) end
	if x>425 and x<445 and y>2 and y<22 then
		image.blit(riducih,425,2)
		if buttons.cross then
			pause_thread(4,getproc_thread())
			PROC_ID_R=nil
			PROC_THREAD_PROC=nil
		end
	else image.blit(riduci,425,2) end
end

function SISTEMA_pagina1(X,r,c,R,C,IMG_ACC_IN,IMG_ACC,IMG_ACC_LIST)
	X=60
	while true do
		screen.clear(nero)
		buttons.read()
		image.blit(sistema1,0,0)
		draw.fillrect(7,26,140,30,color.new(105,105,105))
		screen.print(255,43,tuser,0.7,rosso)
		screen.print(240,65,tpass,0.7,rosso)
		draw.fillrect(168+C*X,118+R*X,44,44,rosso)
		for i=1,10 do
			if x>170+c*X and x<210+c*X and y>120+r*X and y<160+r*X then
				draw.fillrect(168+c*X,118+r*X,44,44,nero)
				if buttons.cross then 
					ini.write("SYSTEM/SYSTEM32/ACC/Account.ini","USER1","immagine",IMG_ACC_LIST[i].path)
					IMG_ACC_IN=i
					if IMG_ACC_IN>5 then R=1 else R=0 end
					C=IMG_ACC_IN-((R*5)+1)
				end
			end
			image.blit(IMG_ACC[i],170+c*X,120+r*X)
			if c==4 then c=0 r=r+1 else c=c+1 end	
		end
		r=0 c=0
		SISTEMA_ESCI()
		if x>=5 and x<=148 and y>=119 and y<=149 then
		draw.fillrect(7,119,140,30,color.new(119,119,119))
			if buttons.cross then
				return 4
			end
		elseif x>=5 and x<=148 and y>=57 and y<=87 then
		draw.fillrect(7,56,140,30,color.new(119,119,119))
			if buttons.cross then
				return 2
			end
		elseif x>=5 and x<=148 and y>=88 and y<=118 then
		draw.fillrect(7,87,140,30,color.new(119,119,119))
			if buttons.cross then
				return 3
			end
		elseif x>=5 and x<=148 and y>=150 and y<=180 then
		draw.fillrect(7,149,140,30,color.new(119,119,119))
			if buttons.cross then
				return 5
			end
		end
		SISTEMA_menu()
		startbar(x,y)
		HOME()
		x,y=mouse(x,y,freccia)
		screen.flip()
	end
end


function SISTEMA_pagina2(X,Y,CPU,NICK)
while true do
	screen.clear(nero)
	buttons.read()
	image.blit(sistema2,0,0)
	draw.fillrect(7,56,140,30,color.new(105,105,105))
	SISTEMA_ESCI()
	if X>0 and Y>0 then
 		draw.fillrect(X,Y,7,7,color.new(0,66,255))
	end
	if CPU==333 then
		X=215 Y=153
	elseif CPU==222 then 
		X=305 Y=153
	elseif CPU==100 then
		X=397 Y=153
	end 
	if MSGshowB==false then
	if (x>=213 and x<=224 and y>=151 and y<=162 and buttons.released.cross) then
    		X=215 Y=153
    		os.cpu(333)
		ini.write("SYSTEM/SYSTEM32/ACC/Sistema.ini","cpu",os.cpu())
		CPU = 333
	elseif (x>=303 and x<=314 and y>=151 and y<=162 and buttons.released.cross) then
    		X=305 Y=153
    		os.cpu(222)
		ini.write("SYSTEM/SYSTEM32/ACC/Sistema.ini","cpu",os.cpu())
		CPU=222
	elseif(x>=395 and x<=406 and y>=151 and y<=162 and buttons.released.cross and CPU~=100) then
		MSGshowB=true
	end
	end
	screen.print(200,55,NICK,0.7,nero)
	prbar(200,80,250,15,os.infoms0().used,os.infoms0().max,color.new(0,255,0),color.new(196,195,195),false)
	screen.print(220,80,(os.infoms0().used).." bytes ".." / "..(os.infoms0().max).." bytes",0.5,nero)
	prbar(240,172,200,15,(os.totalram()-os.ram()),os.totalram(),color.new(0,255,0),color.new(196,195,195),false)
	screen.print(245,172,(os.totalram()-os.ram()).." bytes ".." / "..(os.totalram()).." bytes",0.5,nero)
	if(MSGshowB==true)then
		if MSGBOX("Attenzione","Impostando la frequenza della CPU al minimo il sistema potrebbe rallentare",__MBOKCANC,__MBICONINFO) == __MBOK then
			X=397 Y=153
    			os.cpu(100)
			ini.write("SYSTEM/SYSTEM32/ACC/Sistema.ini","cpu",os.cpu())
			CPU=100
		end
	end
	if MSGshowB==false then
	if x>=5 and x<=148 and y>=26 and y<=56 then
		draw.fillrect(7,26,140,30,color.new(119,119,119))
		if buttons.cross then
			return 1
		end
	elseif x>=5 and x<=148 and y>=88 and y<=118 then
		draw.fillrect(7,87,140,30,color.new(119,119,119))
		if buttons.cross then
			return 3
		end
	elseif x>=5 and x<=148 and y>=119 and y<=149 then
		draw.fillrect(7,118,140,30,color.new(119,119,119))
		if buttons.cross then
			return 4
		end
	elseif x>=5 and x<=148 and y>=150 and y<=180 then
		draw.fillrect(7,149,140,30,color.new(119,119,119))
		if buttons.cross then
			return 5
		end
	end
	end
	SISTEMA_menu()
	startbar(x,y)
	HOME()
	x,y=mouse(x,y,freccia)
	screen.flip()
end
end

function SISTEMA_pagina3()
	while true do
		screen.clear(nero)
		buttons.read()
		image.blit(sistema3,0,0)
		draw.fillrect(7,87,140,30,color.new(105,105,105))
		SISTEMA_ESCI()
		if x<200 or x>250 or x>=200 and x<=250 and y<130 or y>180 then
    			image.blit(ripristino,200,130)
		else
    			image.blit(ripristinoh,200,130)
    			if buttons.cross then
				MSGshowB=true
         			if files.exists("ms0:/PSP/GAME/NINOS/vecchia_versione.rar")==false then
					MSGtitolo="Errore"
					MSGerrore="Il file immagine della vecchia versione dell'OS non è stato trovato"
				else
					MSGtitolo="Attenzione"
					MSGerrore="Procedere con il ripristino della vecchia versione dell'OS?"
				end
    			end
		end
		if x<380 or x>430 or x>=380 and x<=430 and y<130 or y>180 then
			image.blit(ripristino2,380,130)
		else
			image.blit(ripristino2h,380,130)
			if buttons.cross then
				files.delete("SYSTEM/SYSTEM32/ACC/Account.ini")
				ini.write("SYSTEM/SYSTEM32/ACC/Account.ini","cpu","222")
				ini.write("SYSTEM/SYSTEM32/ACC/Account.ini","background_lock","ms0:/PSP/GAME/NINOS/SYSTEM/SYSTEM32/SFONDI/default.jpg")
				ini.write("SYSTEM/SYSTEM32/ACC/Account.ini","background_desk","ms0:/PSP/GAME/NINOS/SYSTEM/SYSTEM32/SFONDI/default.jpg")
				os.delay(1000)
				riavvia()
			end
		end
		if MSGshowB==true then
			if(MSGtitolo~=nil and MSGtitolo=="Errore") then
				MSGBOX(MSGtitolo,MSGerrore,__MBCANC,__MBICONERROR)
			elseif(MSGtitolo~=nil and MSGtitolo=="Attenzione")then
				MSGBOX(MSGtitolo,MSGerrore,__MBOKCANC,__MBICONINFO)
			end
		end
	if x>=5 and x<=148 and y>=26 and y<=56 then
		draw.fillrect(7,26,140,30,color.new(119,119,119))
		if buttons.cross then
			return 1
		end
	elseif x>=5 and x<=148 and y>=57 and y<=87 then
		draw.fillrect(7,57,140,30,color.new(119,119,119))
		if buttons.cross then
			return 2
		end
	elseif x>=5 and x<=148 and y>=119 and y<=149 then
		draw.fillrect(7,118,140,30,color.new(119,119,119))
		if buttons.cross then
			return 4
		end
	elseif x>=5 and x<=148 and y>=150 and y<=180 then
		draw.fillrect(7,149,140,30,color.new(119,119,119))
		if buttons.cross then
			return 5
		end
	end
	SISTEMA_menu()
	startbar(x,y)
	HOME()
	x,y=mouse(x,y,freccia)
	screen.flip()
	end
end

function SISTEMA_pagina4()
	while true do
		screen.clear(nero)
		buttons.read()
		image.blit(sistema4,0,0)
		draw.fillrect(7,118,140,30,color.new(105,105,105))
		SISTEMA_ESCI()
		if x>=254 and x<=384 and y>=130 and y<=160 then
			draw.fillrect(254,130,150,30,color.new(128,128,128))
			screen.print(255,136,"Cerca aggiornamenti",0.7,rosso)
			if buttons.cross then
				aggiornamento()
			end
		else
			draw.fillrect(254,130,150,30,bianco)
			screen.print(255,136,"Cerca aggiornamenti",0.7,nero)
		end
		if x>=5 and x<=148 and y>=26 and y<=56 then
		draw.fillrect(7,26,140,30,color.new(119,119,119))
			if buttons.cross then
				return 1
			end
		elseif x>=5 and x<=148 and y>=57 and y<=87 then
		draw.fillrect(7,56,140,30,color.new(119,119,119))
			if buttons.cross then
				return 2
			end
		elseif x>=5 and x<=148 and y>=88 and y<=118 then
		draw.fillrect(7,87,140,30,color.new(119,119,119))
			if buttons.cross then
				return 3
			end
		elseif x>=5 and x<=148 and y>=150 and y<=180 then
		draw.fillrect(7,149,140,30,color.new(119,119,119))
			if buttons.cross then
				return 5
			end
		end
		SISTEMA_menu()
		startbar(x,y)
		HOME()
		x,y=mouse(x,y,freccia)
		screen.flip()
	end
end

function SISTEMA_pagina5()
	while true do
		screen.clear(nero)
		buttons.read()
		image.blit(sistema5,0,0)
		draw.fillrect(7,149,140,30,color.new(105,105,105))
		if x>=5 and x<=148 and y>=26 and y<=56 then
		draw.fillrect(7,26,140,30,color.new(119,119,119))
			if buttons.cross then
				return 1
			end
		elseif x>=5 and x<=148 and y>=119 and y<=149 then
		draw.fillrect(7,119,140,30,color.new(119,119,119))
			if buttons.cross then
				return 4
			end
		elseif x>=5 and x<=148 and y>=57 and y<=87 then
		draw.fillrect(7,56,140,30,color.new(119,119,119))
			if buttons.cross then
				return 2
			end
		elseif x>=5 and x<=148 and y>=88 and y<=118 then
		draw.fillrect(7,87,140,30,color.new(119,119,119))
			if buttons.cross then
				return 3
			end
		end
		SISTEMA_ESCI()
		SISTEMA_menu()
		startbar(x,y)
		HOME()
		x,y=mouse(x,y,freccia)
		screen.flip()
	end
end

function AVVIO_PROG()
local X=0 
local Y=0 
local pagina=1
local NICK=os.nick() 
local CPU=os.cpu()
local r=0 
local c=0
local R=0 
local C=0
local IMG_ACC={}
local IMG_ACC_LIST=files.listfiles("SYSTEM/SYSTEM32/ACC/IMGPR")
local IMG_ACC_IN=0

for i=1,10 do
	IMG_ACC[i]=image.load(IMG_ACC_LIST[i].path)
	image.resize(IMG_ACC[i],40,40)
	if IMG_ACC_ATT==IMG_ACC_LIST[i].path then
		IMG_ACC_IN=i
	end
end

if IMG_ACC_IN>5 then R=1 else R=0 end
C=IMG_ACC_IN-((R*5)+1)

while true do
	screen.clear(nero)
	buttons.read()
	if pagina==2 then
		pagina=SISTEMA_pagina2(X,Y,CPU,NICK)
	elseif pagina==1 then
		pagina=SISTEMA_pagina1(X,r,c,R,C,IMG_ACC_IN,IMG_ACC,IMG_ACC_LIST)
	elseif pagina==3 then
		pagina=SISTEMA_pagina3()
	elseif pagina==4 then
		pagina=SISTEMA_pagina4()
	elseif pagina==5 then
		pagina=SISTEMA_pagina5()
	end
end
end

image.resize(SISTEMA_ICO,15,15)
if sistema1==nil or sistema2==nil or sistema3==nil or sistema4==nil or ripristino==nil or ripristinoh==nil or ripristino2==nil or ripristino2h==nil then
	bsod("Mancano alcuni file di sistema")
end
if new_thread(4,SISTEMA_ICO)==false then bsod("Impossibile creare thread per avviare il programma") end
SISTEMA_ICO=nil
resume_thread(4)

