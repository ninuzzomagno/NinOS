files.cdir("ms0:/PSP/GAME/NINOS")
require=("SYSTEM.SYSTEM32.ASR")
require=("SCRIPT")

local PSTEAMP_ICO=image.load("SYSTEM/SYSTEM32/ICONE/iconsteam.png")
local sfondo=image.load("SYSTEM/SYSTEM32/PROGRAM/PSteamP_home.jpg")
local Coloreh=color.new(38,38,38)
local Colore=color.new(23,23,23)
local imgDefault=image.load("SYSTEM/SYSTEM32/ICONE/default.png")  
local IMGgame={}
local NMgame={}
local IMGhomebrew={}
local NMhomebrew={}
local X=83 
local Y=63

function READ_INFO(homebrew,z,INFO,GIOCHI,HOMEBREW)
	if homebrew==false then
		INFO[1] = math.floor((GIOCHI[z].size)/1024/1024)
		INFO[2] = GIOCHI[z].ext
		if game.info(GIOCHI[z].path).APP_VER ~=nil then INFO[3] = game.info(GIOCHI[z].path).APP_VER 
		else INFO[3] = "sconosciuto" end
		if game.info(GIOCHI[z].path).DISC_ID ~=nil then INFO[4] = game.info(GIOCHI[z].path).DISC_ID 
		else INFO[4] = "sconosciuto" end
		if game.info(GIOCHI[z].path).PSP_SYSTEM_VER ~=nil then INFO[5] = game.info(GIOCHI[z].path).PSP_SYSTEM_VER 
		else INFO[5] = "sconosciuto" end
		if game.info(GIOCHI[z].path).TITLE ~=nil then INFO[6] = game.info(GIOCHI[z].path).TITLE 
		else INFO[6] = "sconosciuto" end
	else
		INFO[1] = "sconosciuto"--HOMEBREW[z].size
		INFO[2] = "pbp"
		if game.info((HOMEBREW[z].path).."/EBOOT.PBP").APP_VER ~=nil then INFO[3] = game.info((HOMEBREW[z].path).."/EBOOT.PBP").APP_VER 
		else INFO[3] = "sconosciuto" end
		if game.info((HOMEBREW[z].path).."/EBOOT.PBP").DISC_ID ~=nil then INFO[4] = game.info((HOMEBREW[z].path).."/EBOOT.PBP").DISC_ID 
		else INFO[4] = "sconosciuto" end
		if game.info((HOMEBREW[z].path).."/EBOOT.PBP").PSP_SYSTEM_VER ~=nil then INFO[5] = game.info((HOMEBREW[z].path).."/EBOOT.PBP").PSP_SYSTEM_VER 
		else INFO[5] = "sconosciuto" end
		if game.info((HOMEBREW[z].path).."/EBOOT.PBP").TITLE ~=nil then INFO[6] = game.info((HOMEBREW[z].path).."/EBOOT.PBP").TITLE 
		else INFO[6] = "sconosciuto" end
	end
	return INFO,GIOCHI,HOMEBREW
end

function PSTEAMP_ESCI(homebrew,MAX1,MAX2,z)
	if x>450 and x<470 and y>2 and y<22 then
		image.blit(chiudih,450,2)
    		if buttons.released.cross then
			Colore=nil Coloreh=nil 
			IMGgame=nil NMgame=nil GIOCHI=nil 
			IMGhomebrew=nil Mhomebrew=nil HOMEBREW=nil INFO=nil 		
			gameMax=nil homebrewMax=nil imgDefault=nil homebrew=nil
			A=nil MAX1=nil MAX2=nil X=nil Y=nil z=nil
			destroy_thread(1,getproc_thread())
        		files.cdir("ms0:/PSP/GAME/NINOS")
			dofile("SYSTEM/SYSTEM32/desktop.lua")
    		end
	else image.blit(chiudi,450,2) end
    	if x>425 and x<445 and y>2 and y<22 then
		image.blit(riducih,425,2)
		if buttons.released.cross then
			pause_thread(1,getproc_thread())
			PROC_ID_R=nil
			PROC_THREAD_PROC=nil
		end
	else image.blit(riduci,425,2) end
end

function PSTEAMP_menu(homebrew,A,MAX1,MAX2,z,homebrewMax,gameMax,INFO,GIOCHI,HOMEBREW)
	if homebrew==false then
		draw.fillrect(6,25,234,30,Coloreh)
		screen.print(80,33,"GIOCHI",0.8,rosso)
		if x>=240 and x<=474 and y>=25 and y<=55 then
			draw.fillrect(240,25,233,30,Coloreh)
			screen.print(315,33,"HOMEBREW",0.8,rosso)
			if buttons.cross then
				Y=63 z=1 MAX2=12 A=1 X=83
				homebrew,MAX2,homebrewMax,INFO,HOMEBREW=HomebrewList(homebrew,z,MAX2,homebrewMax,INFO,HOMEBREW)
			end
		else screen.print(315,33,"HOMEBREW",0.8,bianco) end
	else
		draw.fillrect(240,25,233,30,Coloreh)
	 	screen.print(315,33,"HOMEBREW",0.8,rosso)
		if x>=6 and x<=233 and y>=25 and y<=55 then
			draw.fillrect(6,25,234,30,Coloreh)
			screen.print(80,33,"GIOCHI",0.8,rosso)
			if buttons.cross then
				Y=63 z=1 MAX1=12 A=1 X=83
				homebrew,MAX1,gameMax,INFO,GIOCHI=GameList(homebrew,z,MAX1,gameMax,INFO,GIOCHI)
			end
		else screen.print(80,33,"GIOCHI",0.8,bianco) end
	end
	return homebrew,A,MAX1,MAX2,z,homebrewMax,gameMax,INFO,GIOCHI,HOMEBREW
end

function GameList(homebrew,z,MAX1,gameMax,INFO,GIOCHI)
	GIOCHI=files.listfiles("ms0:/ISO")
	if GIOCHI ~=nil then
	gameMax=table.getn(GIOCHI)
	if MAX1 > gameMax then MAX1=gameMax end
	for i=1,gameMax do
		if string.len(GIOCHI[i].name)<18 then NMgame[i]=(GIOCHI[i].name)
		else NMgame[i]=string.sub(GIOCHI[i].name,1,15).."..." end
		IMGgame[i]=game.geticon0(GIOCHI[i].path)
		image.scale(IMGgame[i],70)
	end
	homebrew=false
	INFO,GIOCHI,HOMEBREW=READ_INFO(homebrew,z,INFO,GIOCHI,HOMEBREW)
	return homebrew,MAX1,gameMax,INFO,GIOCHI
	end
end

function HomebrewList(homebrew,z,MAX2,homebrewMax,INFO,HOMEBREW)
	HOMEBREW=files.listdirs("ms0:/PSP/GAME") 
	if HOMEBREW~=nil then
	homebrewMax=table.getn(HOMEBREW)
	if MAX2 > homebrewMax then MAX2=homebrewMax end
	for i=1,homebrewMax do
		if string.len(HOMEBREW[i].name)>18 then NMhomebrew[i]=string.sub(HOMEBREW[i].name,1,15).."..."
		else NMhomebrew[i]=string.sub(HOMEBREW[i].name,1,18) end
		IMGhomebrew[i]=game.geticon0((HOMEBREW[i].path).."/EBOOT.PBP")
		if IMGhomebrew[i]==nil then IMGhomebrew[i]=imgDefault end
		image.scale(IMGhomebrew[i],70) 
	end
	homebrew=true
	INFO,GIOCHI,HOMEBREW=READ_INFO(homebrew,z,INFO,GIOCHI,HOMEBREW)
	return homebrew,MAX2,homebrewMax,INFO,HOMEBREW
	end
end

function AVVIO_PROG()

local HOMEBREW=nil
local GIOCHI=nil
local INFO={}
local MAX1=12 
local MAX2=12 
local z=1
local homebrew=false 
local A=1
local gameMax=nil
local homebrewMax=nil

homebrew,MAX1,gameMax,INFO,GIOCHI=GameList(homebrew,z,MAX1,gameMax,INFO,GIOCHI)

while true do
	screen.clear(nero)
	buttons.read()
	image.blit(sfondo,0,0)
	homebrew,A,MAX1,MAX2,z,homebrewMax,gameMax,INFO,GIOCHI,HOMEBREW = PSTEAMP_menu(homebrew,A,MAX1,MAX2,z,homebrewMax,gameMax,INFO,GIOCHI,HOMEBREW)
	if homebrew==false then
		if GIOCHI~=nil then 
		for i=A,MAX1 do
			if i==z then 
				if string.len(GIOCHI[i].name) > 18 then
					X = screen.print(X,Y,string.sub(GIOCHI[i].name,1,-5),0.6,rosso,Colore,__SSEESAW,129)
				else screen.print(20,Y,NMgame[i],0.6,rosso) end
			else screen.print(20,Y,NMgame[i],0.6,bianco) end
			Y=Y+15
			if i==MAX1 then
				i=A
				Y=63
			end
		end
		image.blit(IMGgame[z],180,70)
		if buttons.l and z>1 then
			z=z-1
			INFO,GIOCHI,HOMEBREW=READ_INFO(homebrew,z,INFO,GIOCHI)
			if z<A then
				A=A-1
				MAX1=MAX1-1
			end
		elseif buttons.r and z<gameMax then
			z=z+1
			INFO,GIOCHI,HOMEBREW=READ_INFO(homebrew,z,INFO,GIOCHI,HOMEBREW)
			if z>MAX1 then
				MAX1 = MAX1+1
				A = A+1
			end
		end
		if gameMax >= MAX1 then
		scrollbar(9,60,240,2,z,12,gameMax,bianco)
		end
		end
	else	
		if HOMEBREW~=nil then 
		for i=A,MAX2 do
			if i==z then 
				if string.len(HOMEBREW[i].name) > 18 then
					X = screen.print(X,Y,HOMEBREW[i].name,0.6,rosso,Colore,__SSEESAW,129)
				else screen.print(20,Y,NMhomebrew[i],0.6,rosso) end
			else screen.print(20,Y,NMhomebrew[i],0.6,bianco) end
			Y=Y+15
			if i==MAX2 then
				i=A
				Y=63
			end
		end
		image.blit(IMGhomebrew[z],180,70)
		if buttons.l and z>1 then
			z=z-1
			INFO,GIOCHI,HOMEBREW=READ_INFO(homebrew,z,INFO,GIOCHI,HOMEBREW)
			if z<A then
				A=A-1
				MAX2=MAX2-1
			end
		elseif buttons.r and z<homebrewMax then
			z=z+1
			INFO,GIOCHI,HOMEBREW=READ_INFO(homebrew,z,INFO,GIOCHI,HOMEBREW)
			if z>MAX2 then
				MAX2 = MAX2+1
				A = A+1
			end
		end
		if homebrewMax >= MAX2 then
		scrollbar(11,60,240,2,z,12,homebrewMax,bianco)
		end
		end
	end
	screen.print(180,130,"Tipo di file :",0.6,bianco)
	screen.print(180,145,"Versione app :",0.6,bianco)
	screen.print(180,160,"ID app :",0.6,bianco)
	screen.print(180,175,"Richiede ofw minimo :",0.6,bianco)
	screen.print(180,190,"Spazio occupato :",0.6,bianco)
	screen.print(290,80,"Titolo :",0.6,bianco)
	screen.print(260,130,INFO[2],0.6,bianco)
	screen.print(280,145,INFO[3],0.6,bianco)
	screen.print(240,160,INFO[4],0.6,bianco)
	screen.print(320,175,INFO[5],0.6,bianco)
	screen.print(300,190,INFO[1].." MB",0.6,bianco)
	if homebrew==false then screen.print(100,0,"false",0.6,rosso)
	else screen.print(100,0,"true",0.6,rosso) end
	screen.print(340,80,INFO[6],0.6,bianco,color.new(0,0,0,0),__ALEFT,120)
	if x>=360 and x<=460 and y>=215 and y<=240 then
		draw.fillrect(360,215,100,25,nero)
		screen.print(390,220,"AVVIA",0.6,rosso)
		if buttons.cross then
			if homebrew==true and HOMEBREW~=nil then files.cdir("ms0:/PSP/GAME")game.launch((HOMEBREW[5].name).."/EBOOT.PBP")
			elseif homebrew==false and GIOCHI~=nil then game.launch(GIOCHI[z].path) end
		end
	else
		draw.fillrect(360,215,100,25,Colore)
		screen.print(390,220,"AVVIA",0.6,bianco)
	end
	PSTEAMP_ESCI(homebrew,MAX1,MAX2,z)
	startbar(x,y)
	HOME()
	x,y=mouse(x,y,freccia)
	screen.flip()
end
end

image.resize(PSTEAMP_ICO,15,15)
if sfondo==nil or imgDefault==nil then bsod("Mancano alcuni file di sistema") end
if new_thread(1,PSTEAMP_ICO)==false then bsod("Impossibile creare thread per avviare il programma") end
--AVVIO_PROG()
