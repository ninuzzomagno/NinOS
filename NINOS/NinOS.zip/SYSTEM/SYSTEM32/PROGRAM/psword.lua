files.cdir("ms0:/PSP/GAME/NINOS/SYSTEM/SYSTEM32")
require=("ASR")

local h_word=image.load("PROGRAM/PsWord.jpg")
local ico_txt=image.load("ICONE/ico_txt.png")
local ico_ini=image.load("ICONE/ico_ini.png")
local word=image.load("PROGRAM/word.jpg")
local carica=image.load("ICONE/load.png")
local titolo = nil errore=nil

if h_word==nil or ico_txt==nil or ico_ini==nil or word==nil or titolo==nil  or carica==nil then
	bsod("Mancano alcuni file di sistema")
end

function avvio()
	local t=timer.new(0)
	local angle = 0
	timer.start(t)
	image.center(carica)
	while timer.time(t)<=5000 do
		screen.clear(nero)
		image.blit(word,0,0)
		image.blit(carica,240,204)
		image.rotate(carica,angle)
		angle = angle + 5
		screen.flip()
	end
	carica = nil
	word = nil
end

function apri(l_file,i)
	local t = io.open(l_file[i].path,'r')
	local tr = t:read()
	t:close()
	while true do
		screen.clear(nero)
		buttons.read()
		startbar(x,y)
		draw.fillrect(0,50,180,100,bianco)
		screen.print(X+Z*110,Y+z*120,tr,0.6,nero,color.new(0,0,0,0),__ACENTER,200)
		x,y=mouse(x,y,freccia)
		screen.flip()
	end
end

if files.exists("ms0:/Word")==false then files.mkdir("ms0:/Word") end
avvio()
local nuovo_b = false apri_b = false
local l_file=files.listfiles("ms0:/Word") l_max=table.getn(l_file)
local max=6 A=1 X=210 Y=90 z=0 Z=0 sel=-1 SEL=-1 BUTTON_MSG=nil ICON_MSG=nil

if max > l_max then max = l_max end

while true do
	screen.clear(nero)
	buttons.read()
	image.blit(h_word,0,0)
	if buttons.cross and x>=0 and x<=152 and y>=65 and y<=95 then nuovo_b=true apri_b=false sel=-1 SEL=-1
	elseif sel~=-1 and SEL~=-1 and buttons.cross and  x>=0 and x<=152 and y>=115 and y<=145 then apri_b=true nuovo_b=false 
	elseif buttons.cross and x>=50 and x<=100 and y>=165 and y<=195 then
		files.cdir("ms0:/PSP/GAME/NINOS")
		dofile("SYSTEM/SYSTEM32/desktop.lua")
	end
	if nuovo_b == true then draw.fillrect(0,65,152,30,color.new(0,0,139,100)) 
	elseif apri_b == true then 	draw.fillrect(0,115,152,30,color.new(0,0,139,100)) end
	if MSGshowB == false then
		if buttons.cross and x>=180 and x<=240 and y>=20 and y<=80 then sel=0 SEL=0
		elseif buttons.cross and x>=290 and x<=350 and y>=20 and y<=80 then sel=1 SEL=0
		elseif buttons.cross and x>=400 and x<=460 and y>=20 and y<=80 then sel=2 SEL=0
		elseif buttons.cross and x>=180 and x<=240 and y>=140 and y<=200 then sel=0 SEL=1
		elseif buttons.cross and x>=290 and x<=350 and y>=140 and y<=200 then sel=1 SEL=1
		elseif buttons.cross and x>=400 and x<=460 and y>=140 and y<=200 then sel=2 SEL=1
		elseif buttons.cross and ((x<0 or x>152 and y<115 or y>145) and (((x<180 or x>240) or (x<290 or x>350) or (x<400 or x>460))  and ((y<20 or y>80) or (y<140 or y>200 )))) then sel=-1 SEL=-1 end
	end
	if sel~=-1 and SEL~=-1 then draw.fillrect(170+sel*110,15+SEL*120,80,70,color.new(255,0,255,150)) end
	for i=A,max do
		if l_file[i].ext == "txt" then image.blit(ico_txt,180+Z*110,20+z*120)
		elseif l_file[i].ext == "ini" then image.blit(ico_ini,180+Z*110,20+z*120) end
		if string.len(l_file[i].name) > 17 then
			screen.print(X+Z*110,Y+z*120,string.sub(l_file[i].name,1,17),0.6,nero,color.new(0,0,0,0),__ACENTER,80)
		else
			screen.print(X+Z*110,Y+z*120,l_file[i].name,0.6,nero,color.new(0,0,0,0),__ACENTER,80)
		end
		Z=Z+1
		if i==3 then
			z=z+1
			Z=0
		elseif i==max then
			z=0
			Z=0
		end
	end
	if buttons.r and max<l_max then
		if max+6<=l_max then
 			max = max + 6
			A = A + 6
		else
			max = l_max
			A = A+6
		end
		z=0
		Z=0
		SEL=-1
		sel=-1
	elseif buttons.l and A>1 then
		max = A-1
		A = A-6
		z=0
		Z=0
		SEL=-1
		sel=-1
	end
	if apri_b == true then
		if SEL == 0 then
			if l_file[sel+1].ext ~= "txt" then
				MSGshowB = true
				titolo="Errore"
				errore="Il programma non supporta questo formato"
			else
				os.delay(2000)
			       apri(l_file,(sel+1))
			end
		elseif SEL == 1 then
			if l_file[3+sel+1].ext ~= "txt" then
				MSGshowB = true
				titolo="Errore"
				errore="Il programma non supporta questo formato"

			else
				os.delay(2000)
			       apri(l_file,(3+sel+1))
			end
		end
	end
	if MSGshowB==true then
		MSGreturn = MSGBOX(titolo,errore,__MBOK,__MBICONERROR)
		if(MSGreturn == __MBOK) then
			MSGshowB=false
			z=0
			Z=0
			SEL=-1
			sel=-1
			apri_b=false
		end
	end	
	--screen.print((480-(screen.textwidth((math.floor(max/6)).."/"..(math.floor(l_max/max))))/2,0,(math.floor(max/6)).."/"..(math.floor(l_max/max)),0.5,nero)
	startbar(x,y)
	x,y=mouse(x,y,freccia)
	screen.flip()
end
