files.cdir("ms0:/PSP/GAME/NINOS")
require=("SYSTEM.SYSTEM32.ASR")

local sfondo=image.load("SYSTEM/SYSTEM32/PROGRAM/immagini.jpg")
local png=image.load("SYSTEM/SYSTEM32/ICONE/png.png")
local jpg=image.load("SYSTEM/SYSTEM32/ICONE/jpg.png")
local ico_fileg=image.load("SYSTEM/SYSTEM32/ICONE/ico_fileg.png")
local ico_cartella=image.load("SYSTEM/SYSTEM32/ICONE/ico_cartella.png")

l_img=files.list("ms0:/")
l_max=table.getn(l_img)
max=12 yr=40 xr=41 c=1 z=1 p=1 C=1

function IMGV_ESCI()
	if x>450 and x<470 and y>2 or y<22 then
		image.blit(chiudih,450,2)
    		if buttons.cross then
			destroy_thread(5,getproc_thread())
        		files.cdir("ms0:/PSP/GAME/NINOS")
        		dofile("SYSTEM/SYSTEM32/desktop.lua")
    		end
	else image.blit(chiudi,450,2) end
	if x>425 and x<445 and y>2 and y<22 then
		image.blit(riducih,425,2)
		if buttons.released.cross then
			pause_thread(1,getproc_thread())
			PROC_ID_R=nil
			PROC_THREAD_PROC=nil
		end
	else image.blit(riduci,425,2) end
end

function AVVIO_PROG()
while true do
buttons.read()
image.blit(sfondo,0,0)
A=1 a=1 X=41 Y=40
if c>0 and z>0 then draw.fillrect((11+c*30+(c-1)*92)-1,((z-1)*100-(z-2)*40)-1,32,41,color.new(0,0,0,100)) end
for i=p,max do
    if max == l_max and l_max > 12 then screen.print(30,228,"L",0.7,color.new(0,0,0))
    elseif l_max>12 then screen.print(420,228,"R",0.7,color.new(0,0,0)) end
    if l_img[i].ext == "png" then image.blit(png,11+a*30+(a-1)*92,Y) 
    elseif l_img[i].ext == "jpg" then image.blit(jpg,11+a*30+(a-1)*92,Y)
    elseif l_img[i].ext == "bmp" then image.blit(bmp,11+a*30+(a-1)*92,Y)
    elseif l_img[i].ext == "gif" then image.blit(gif,11+a*30+(a-1)*92,Y)
    elseif l_img[i].directory then image.blit(ico_cartella,11+a*30+(a-1)*92,Y)
    else image.blit(ico_fileg,11+a*image.getw(jpg)+(a-1)*92,Y) end
    screen.print(11+a*image.getw(jpg)+(a-1)*92,Y+40,string.sub(l_img[i].name,1,6),0.5,color.new(0,0,0))
    if i==A*4 then A=A+1 Y=(A-1)*100-(A-2)*40 end
    if a==4 then a=1 else a=a+1 end
end
if y>=220 and y<=259  then z=4
elseif y>=160 and y<=199 then z=3 
elseif y>=100 and y<=139 then z=2
elseif y>=40 and y<=79 then z=1
else z=0 end
if x>=407 and x<=437 then c=4 
elseif x>=285 and x<=315 then c=3 
elseif x>=163 and y<=193 then c=2
elseif x>=41 and x<=71 then c=1 
else c=0 end
if buttons.held.cross and z>0 and c>0 then
    C=(z*4)+4-c+max-12
    if l_img[C].directory == false and l_img[C].ext ~= "png" and l_img[C].ext ~= "jpg" and l_img[C].ext ~= "gif" and l_img[C].ext ~= "bmp" then ERRORE=true  sound.play(s_error) er="Formato file non supportato :("
    elseif l_img[C].directory == false and l_img[C].ext == "png" or l_img[C].ext == "jpg" or l_img[C].ext == "gif" or l_img[C].ext == "bmp" then
        immagine=image.load(l_img[C].name)
        if immagine == nil then er="Immagine troppo grande\nper essere visualizzata :(" ERRORE=true sound.play(s_error)
        else image.blit(immagine,240-(image.getw(immagine)/2),136-(image.geth(immagine)/2)) ERRORE=false end 
    end
end
if ERRORE==true then
    errore(er)
    if buttons.start then
        ERRORE=false
    end
end
if buttons.r and max < l_max then
    p=max+1
    if l_max >= max+12 then max=max+12
    else max=l_max end
elseif buttons.l and p > 12 then end
IMGV_ESCI()
HOME()
startbar(x,y)
x,y=mouse(x,y,freccia)
screen.flip()
end
end

if new_thread(5,IMGV_ICO)==false then bsod("Impossibile creare thread per avviare il programma")
