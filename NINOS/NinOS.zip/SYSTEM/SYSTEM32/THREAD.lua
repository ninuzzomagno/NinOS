PROC_ATT_ID={}
PROC_ATT_IMG={}
PROC_ATT=0
THREAD_ATT={}
PROC_THREAD={}

function new_thread(id,img)
	if PROC_ATT==0 then PROC_ATT=1 else PROC_ATT=PROC_ATT+1 end
	PROC_ATT_ID[PROC_ATT]=id
	if PROC_ATT==1 then PROC_THREAD[1]=1 
	else
		for i=1,PROC_ATT-1 do
			if PROC_ATT_ID[i]=id then
				PROC_THREAD[PROC_ATT]=PROC_THREAD[PROC_ATT]+1
			end
		end
	end
	PROC_ATT_IMG[PROC_ATT]=img
	THREAD_ATT[PROC_ATT]=coroutine.create(AVVIO_PROG)
	if THREAD_ATT[PROC_ATT]~=nil then
		return true
	return false
end

function pause_thread(id,proc)
	for i=1,PROC_ATT do
		if PROC_ATT_ID[i]==id and PROC_THREAD[i]==proc then
			return coroutine.yield(THREAD_ATT[i])
		end
	end
end

function resume_thread(id,proc)
	for i=1,PROC_ATT do
		if PROC_ATT_ID[i]==id and PROC_THREAD[i]==proc then
			return coroutine.resume(THREAD_ATT[i])
		end
	end
end

function getid_thread()
	for i=1,PROC_ATT do
		if THREAD_ATT[i]==coroutine.running() then
			return PROC_ATT_ID[i]
		end
	end
end

function getproc_thread()
	for i=1,PROC_ATT do
		if THREAD_ATT[i]==coroutine.running() then
			return PROC_THREAD[i]
		end
	end
end

function destroy_thread(id,proc)
	for i=1,PROC_ATT do
		if PROC_ATT_ID[i]==id then
			PROC_ATT_IMG[i]=nil
			PROC_ATT_ID[i]=nil
			THREAD_ATT[i]=nil
			if i==PROC_ATT then PROC_ATT=PROC_ATT-1 end
			break
		end
	end
	if PROC_ATT~=0 then
		for i=1,PROC_ATT do
			if PROC_ATT_ID[i]==nil and i~=PROC_ATT then
				PROC_ATT_ID[i]=PROC_ATT_ID[i+1]
				PROC_ATT_IMG[i]=PROC_ATT_IMG[i+1]
				THREAD_ATT[i]=THREAD_ATT[i+1]
			end
		end
	end
end

